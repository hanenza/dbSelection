
angular.module("dbSelection")
.controller("LogoutPageController", ["$scope",  function($scope) {
// your code




}])
/*

 */