
angular.module("dbSelection")
.controller("MatrixWeightController", ["$scope",  function($scope) {
// your code




}])
/*

 */