angular.module("dbSelection")
  .controller("SQLEditorController", ["$scope","$document", function($scope, $document) {
  

    

     }]);

 
