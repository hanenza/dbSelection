
angular.module("dbSelection")
.controller("NewProjectController", ["$scope",  function($scope) {
// your code




}])
/*

 */