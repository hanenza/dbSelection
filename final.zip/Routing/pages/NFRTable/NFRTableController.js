angular.module("dbSelection")
  .controller("NFRTableController", ["$scope","$document", function($scope, $document) {
  

  
     }]);

 
