
angular.module("dbSelection")
.controller("RegisterPageController", ["$scope",  function($scope) {
// your code




}])
/*

 */