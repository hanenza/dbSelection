
angular.module("dbSelection")
.controller("RestPasswordController", ["$scope",  function($scope) {
// your code




}])
/*

 */