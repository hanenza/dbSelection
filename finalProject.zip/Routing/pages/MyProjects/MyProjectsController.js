
angular.module("dbSelection")
.controller("MyProjectsController", ["$scope",  function($scope) {
// your code




}])
/*

 */