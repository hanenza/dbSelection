
angular.module("dbSelection")
.controller("AboutPageController", ["$scope",  function($scope) {
// your code




}])
/*

 */